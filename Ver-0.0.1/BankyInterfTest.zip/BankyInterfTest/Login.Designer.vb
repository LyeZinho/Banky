﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Login
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.ConfirmBTN = New System.Windows.Forms.Button()
        Me.AlertLB = New System.Windows.Forms.Label()
        Me.NifTB = New System.Windows.Forms.TextBox()
        Me.PassTB = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'ConfirmBTN
        '
        Me.ConfirmBTN.Location = New System.Drawing.Point(346, 323)
        Me.ConfirmBTN.Name = "ConfirmBTN"
        Me.ConfirmBTN.Size = New System.Drawing.Size(75, 23)
        Me.ConfirmBTN.TabIndex = 0
        Me.ConfirmBTN.Text = "Confirmar"
        Me.ConfirmBTN.UseVisualStyleBackColor = True
        '
        'AlertLB
        '
        Me.AlertLB.AutoSize = True
        Me.AlertLB.Location = New System.Drawing.Point(372, 205)
        Me.AlertLB.Name = "AlertLB"
        Me.AlertLB.Size = New System.Drawing.Size(27, 15)
        Me.AlertLB.TabIndex = 1
        Me.AlertLB.Text = "----"
        '
        'NifTB
        '
        Me.NifTB.Location = New System.Drawing.Point(203, 267)
        Me.NifTB.Name = "NifTB"
        Me.NifTB.Size = New System.Drawing.Size(100, 23)
        Me.NifTB.TabIndex = 2
        Me.NifTB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'PassTB
        '
        Me.PassTB.Location = New System.Drawing.Point(466, 267)
        Me.PassTB.Name = "PassTB"
        Me.PassTB.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.PassTB.Size = New System.Drawing.Size(100, 23)
        Me.PassTB.TabIndex = 3
        Me.PassTB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Login
        '
        Me.AllowDrop = True
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.MediumTurquoise
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.PassTB)
        Me.Controls.Add(Me.NifTB)
        Me.Controls.Add(Me.AlertLB)
        Me.Controls.Add(Me.ConfirmBTN)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "Login"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Banky"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents ConfirmBTN As Button
    Friend WithEvents AlertLB As Label
    Friend WithEvents NifTB As TextBox
    Friend WithEvents PassTB As TextBox
End Class
