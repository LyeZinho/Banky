﻿Public Class Main


    Private Sub InterfacePrincipal_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim Client As New Cliente
        Dim dbc As New DatabaseClients
        Dim dbl As New DatabaseLogin

        dbl.readDb(Client)
        dbc.readDb(Client)
        Dim bal As Double = Convert.ToDouble(Client.Balance)
        MoneyLB.Text = bal.ToString("C", New System.Globalization.CultureInfo("pt-PT"))
    End Sub


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles DepoBTN.Click

    End Sub
End Class