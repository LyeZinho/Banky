﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Main
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MoneyLB = New System.Windows.Forms.Label()
        Me.DepoBTN = New System.Windows.Forms.Button()
        Me.WhitdrawBTN = New System.Windows.Forms.Button()
        Me.TransfBTN = New System.Windows.Forms.Button()
        Me.Transf_LB = New System.Windows.Forms.ListBox()
        Me.MainUIGB = New System.Windows.Forms.GroupBox()
        Me.Senha_TB = New System.Windows.Forms.TextBox()
        Me.Amount_TB = New System.Windows.Forms.TextBox()
        Me.Pass_LB = New System.Windows.Forms.Label()
        Me.Quant_LB = New System.Windows.Forms.Label()
        Me.ConfritmBTN = New System.Windows.Forms.Button()
        Me.Moves_GB = New System.Windows.Forms.GroupBox()
        Me.SendNif_TB = New System.Windows.Forms.TextBox()
        Me.Nifsend_LB = New System.Windows.Forms.Label()
        Me.Orderbydes_BT = New System.Windows.Forms.Button()
        Me.Orderbyasc_BT = New System.Windows.Forms.Button()
        Me.MainUIGB.SuspendLayout()
        Me.Moves_GB.SuspendLayout()
        Me.SuspendLayout()
        '
        'MoneyLB
        '
        Me.MoneyLB.AutoSize = True
        Me.MoneyLB.Font = New System.Drawing.Font("Impact", 26.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.MoneyLB.Location = New System.Drawing.Point(96, 60)
        Me.MoneyLB.Name = "MoneyLB"
        Me.MoneyLB.Size = New System.Drawing.Size(59, 43)
        Me.MoneyLB.TabIndex = 0
        Me.MoneyLB.Text = "----"
        '
        'DepoBTN
        '
        Me.DepoBTN.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.DepoBTN.Location = New System.Drawing.Point(26, 159)
        Me.DepoBTN.Name = "DepoBTN"
        Me.DepoBTN.Size = New System.Drawing.Size(100, 23)
        Me.DepoBTN.TabIndex = 1
        Me.DepoBTN.Text = "Deposito"
        Me.DepoBTN.UseVisualStyleBackColor = True
        '
        'WhitdrawBTN
        '
        Me.WhitdrawBTN.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.WhitdrawBTN.Location = New System.Drawing.Point(26, 205)
        Me.WhitdrawBTN.Name = "WhitdrawBTN"
        Me.WhitdrawBTN.Size = New System.Drawing.Size(100, 23)
        Me.WhitdrawBTN.TabIndex = 2
        Me.WhitdrawBTN.Text = "Levantamento"
        Me.WhitdrawBTN.UseVisualStyleBackColor = True
        '
        'TransfBTN
        '
        Me.TransfBTN.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.TransfBTN.Location = New System.Drawing.Point(132, 159)
        Me.TransfBTN.Name = "TransfBTN"
        Me.TransfBTN.Size = New System.Drawing.Size(92, 23)
        Me.TransfBTN.TabIndex = 3
        Me.TransfBTN.Text = "Transferencia"
        Me.TransfBTN.UseVisualStyleBackColor = True
        '
        'Transf_LB
        '
        Me.Transf_LB.FormattingEnabled = True
        Me.Transf_LB.ItemHeight = 15
        Me.Transf_LB.Location = New System.Drawing.Point(12, 344)
        Me.Transf_LB.Name = "Transf_LB"
        Me.Transf_LB.Size = New System.Drawing.Size(332, 94)
        Me.Transf_LB.TabIndex = 4
        '
        'MainUIGB
        '
        Me.MainUIGB.Controls.Add(Me.TransfBTN)
        Me.MainUIGB.Controls.Add(Me.WhitdrawBTN)
        Me.MainUIGB.Controls.Add(Me.DepoBTN)
        Me.MainUIGB.Controls.Add(Me.MoneyLB)
        Me.MainUIGB.Location = New System.Drawing.Point(12, 22)
        Me.MainUIGB.Name = "MainUIGB"
        Me.MainUIGB.Size = New System.Drawing.Size(332, 273)
        Me.MainUIGB.TabIndex = 6
        Me.MainUIGB.TabStop = False
        '
        'Senha_TB
        '
        Me.Senha_TB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Senha_TB.Location = New System.Drawing.Point(28, 96)
        Me.Senha_TB.Name = "Senha_TB"
        Me.Senha_TB.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.Senha_TB.Size = New System.Drawing.Size(127, 23)
        Me.Senha_TB.TabIndex = 4
        '
        'Amount_TB
        '
        Me.Amount_TB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Amount_TB.Location = New System.Drawing.Point(28, 144)
        Me.Amount_TB.Name = "Amount_TB"
        Me.Amount_TB.Size = New System.Drawing.Size(127, 23)
        Me.Amount_TB.TabIndex = 7
        '
        'Pass_LB
        '
        Me.Pass_LB.AutoSize = True
        Me.Pass_LB.Location = New System.Drawing.Point(28, 75)
        Me.Pass_LB.Name = "Pass_LB"
        Me.Pass_LB.Size = New System.Drawing.Size(39, 15)
        Me.Pass_LB.TabIndex = 8
        Me.Pass_LB.Text = "Senha"
        '
        'Quant_LB
        '
        Me.Quant_LB.AutoSize = True
        Me.Quant_LB.Location = New System.Drawing.Point(28, 126)
        Me.Quant_LB.Name = "Quant_LB"
        Me.Quant_LB.Size = New System.Drawing.Size(69, 15)
        Me.Quant_LB.TabIndex = 9
        Me.Quant_LB.Text = "Quantidade"
        '
        'ConfritmBTN
        '
        Me.ConfritmBTN.BackColor = System.Drawing.Color.Honeydew
        Me.ConfritmBTN.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ConfritmBTN.Location = New System.Drawing.Point(45, 182)
        Me.ConfritmBTN.Name = "ConfritmBTN"
        Me.ConfritmBTN.Size = New System.Drawing.Size(75, 23)
        Me.ConfritmBTN.TabIndex = 10
        Me.ConfritmBTN.Text = "Confirmar"
        Me.ConfritmBTN.UseVisualStyleBackColor = False
        '
        'Moves_GB
        '
        Me.Moves_GB.Controls.Add(Me.SendNif_TB)
        Me.Moves_GB.Controls.Add(Me.Nifsend_LB)
        Me.Moves_GB.Controls.Add(Me.Amount_TB)
        Me.Moves_GB.Controls.Add(Me.ConfritmBTN)
        Me.Moves_GB.Controls.Add(Me.Senha_TB)
        Me.Moves_GB.Controls.Add(Me.Quant_LB)
        Me.Moves_GB.Controls.Add(Me.Pass_LB)
        Me.Moves_GB.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Moves_GB.Location = New System.Drawing.Point(376, 27)
        Me.Moves_GB.Name = "Moves_GB"
        Me.Moves_GB.Size = New System.Drawing.Size(188, 223)
        Me.Moves_GB.TabIndex = 11
        Me.Moves_GB.TabStop = False
        '
        'SendNif_TB
        '
        Me.SendNif_TB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.SendNif_TB.Location = New System.Drawing.Point(28, 49)
        Me.SendNif_TB.Name = "SendNif_TB"
        Me.SendNif_TB.Size = New System.Drawing.Size(127, 23)
        Me.SendNif_TB.TabIndex = 11
        Me.SendNif_TB.Visible = False
        '
        'Nifsend_LB
        '
        Me.Nifsend_LB.AutoSize = True
        Me.Nifsend_LB.Location = New System.Drawing.Point(28, 28)
        Me.Nifsend_LB.Name = "Nifsend_LB"
        Me.Nifsend_LB.Size = New System.Drawing.Size(71, 15)
        Me.Nifsend_LB.TabIndex = 12
        Me.Nifsend_LB.Text = "Nif de envio"
        Me.Nifsend_LB.Visible = False
        '
        'Orderbydes_BT
        '
        Me.Orderbydes_BT.Location = New System.Drawing.Point(12, 315)
        Me.Orderbydes_BT.Name = "Orderbydes_BT"
        Me.Orderbydes_BT.Size = New System.Drawing.Size(30, 23)
        Me.Orderbydes_BT.TabIndex = 12
        Me.Orderbydes_BT.Text = "▼"
        Me.Orderbydes_BT.UseVisualStyleBackColor = True
        '
        'Orderbyasc_BT
        '
        Me.Orderbyasc_BT.Location = New System.Drawing.Point(48, 315)
        Me.Orderbyasc_BT.Name = "Orderbyasc_BT"
        Me.Orderbyasc_BT.Size = New System.Drawing.Size(30, 23)
        Me.Orderbyasc_BT.TabIndex = 14
        Me.Orderbyasc_BT.Text = "▲"
        Me.Orderbyasc_BT.UseVisualStyleBackColor = True
        '
        'Main
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.MediumTurquoise
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.Orderbyasc_BT)
        Me.Controls.Add(Me.Orderbydes_BT)
        Me.Controls.Add(Me.Moves_GB)
        Me.Controls.Add(Me.MainUIGB)
        Me.Controls.Add(Me.Transf_LB)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Name = "Main"
        Me.Text = "Banky"
        Me.MainUIGB.ResumeLayout(False)
        Me.MainUIGB.PerformLayout()
        Me.Moves_GB.ResumeLayout(False)
        Me.Moves_GB.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents MoneyLB As Label
    Friend WithEvents DepoBTN As Button
    Friend WithEvents WhitdrawBTN As Button
    Friend WithEvents TransfBTN As Button
    Friend WithEvents Transf_LB As ListBox
    Friend WithEvents MainUIGB As GroupBox
    Friend WithEvents Senha_TB As TextBox
    Friend WithEvents Amount_TB As TextBox
    Friend WithEvents Pass_LB As Label
    Friend WithEvents Quant_LB As Label
    Friend WithEvents ConfritmBTN As Button
    Friend WithEvents Moves_GB As GroupBox
    Friend WithEvents Orderbydes_BT As Button
    Friend WithEvents Orderbyasc_BT As Button
    Friend WithEvents SendNif_TB As TextBox
    Friend WithEvents Nifsend_LB As Label
End Class
